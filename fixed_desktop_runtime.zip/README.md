# Eaglercraft 1.5.2 Desktop Runtime (22w43a)

This is only meant for low level debug purposes, don't use this to play on public servers as a replacement for the web client, just go buy the real fucking game if that's the reason you're downloading this

These files are simply meant to be reference for anyone having issues getting the desktop runtime to launch via their IDE

Make sure you have at least Java 8 installed and on your path, then run launch.bat if you are on windows or launch.sh if you are on linux
